package com.example.jwt_demo.controller;

import java.util.Hashtable;

import javax.naming.AuthenticationException;
import javax.naming.AuthenticationNotSupportedException;
import javax.naming.Context;
import javax.naming.NamingException;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.jwt_demo.model.ApiResponse;
import com.example.jwt_demo.model.LDAPConstants;
import com.example.jwt_demo.model.LoginRequest;
import com.example.jwt_demo.security.JwtAuthenticationResponse;
import com.example.jwt_demo.security.JwtUtil;
import com.example.jwt_demo.service.CustomUserDetailsService;

import io.micrometer.common.util.StringUtils;

@RestController
@RequestMapping("/api/auth")
public class AuthController {
	@Autowired
    private CustomUserDetailsService customUserDetailsService;

    @Autowired
    JwtUtil jwtUtils;
    
    @SuppressWarnings({ "unchecked", "rawtypes" })
	@PostMapping("/signin")
    public ResponseEntity<?> authenticateUser(@RequestBody LoginRequest loginRequest) throws Exception {    	
    	
    	if(StringUtils.isNotEmpty(loginRequest.getUsername())) {
    		 return new ResponseEntity(new ApiResponse(false, LDAPConstants.USERNAME_OR_PASSWORD_INVALID),
                     HttpStatus.BAD_REQUEST);
    	}
    	if(StringUtils.isNotEmpty(loginRequest.getPassword())) {
   		 return new ResponseEntity(new ApiResponse(false, LDAPConstants.USERNAME_OR_PASSWORD_INVALID),
                    HttpStatus.BAD_REQUEST);
   	}
    	boolean isAuthenticated = authenticate(loginRequest.getUsername(), loginRequest.getPassword());
    	
    	if(!isAuthenticated) {
    		return new ResponseEntity(new ApiResponse(false, LDAPConstants.USERNAME_OR_PASSWORD_INCORRECT),
                    HttpStatus.BAD_REQUEST);
    	}
    	
		 UserDetails userDetails=customUserDetailsService.loadUserByUsername(loginRequest.getUsername());
		 String jwt=jwtUtils.generateToken(userDetails.getUsername());
	        return ResponseEntity.ok(new JwtAuthenticationResponse(jwt));
    }
    
    private boolean authenticate(String userName, String password) throws Exception {

    	System.out.println("loginRequest value is "+userName);
    	
    	Hashtable<String, String> environment = new Hashtable<String, String>();
        
        environment.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
        environment.put(Context.PROVIDER_URL, "");
        environment.put(Context.SECURITY_AUTHENTICATION, "simple");
        environment.put(Context.SECURITY_PRINCIPAL, ""+userName+"@domain");
        environment.put(Context.SECURITY_CREDENTIALS, password);
        environment.put(Context.REFERRAL, "follow");
        
        try
        {
            DirContext context = new InitialDirContext(environment);
            System.out.println("Connected..");
            System.out.println(context.getEnvironment());
            
            return true;
        }
        catch (AuthenticationNotSupportedException exception)
        {
            System.out.println("The authentication is not supported by the server");
        }
 
        catch (AuthenticationException exception)
        {
            System.out.println("Incorrect password or username");
        }
 
        catch (NamingException exception)
        {
            System.out.println("Error when trying to create the context");
            System.out.println(exception);
        }
        return false;
        
    }
}
