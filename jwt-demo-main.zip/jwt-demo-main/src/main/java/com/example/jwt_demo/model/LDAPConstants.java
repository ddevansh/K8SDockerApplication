package com.example.jwt_demo.model;

public interface LDAPConstants{

	String INVALID_TOKEN = "Invalid Token";
	String VALID_TOKEN = "Valid token for user ";
	String USERNAME_OR_PASSWORD_INVALID = "Username or Password should not be empty";
	String USERNAME_OR_PASSWORD_INCORRECT = "Username or Password is not correct";

}
